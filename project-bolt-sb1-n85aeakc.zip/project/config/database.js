const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('finance.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the finance database.');
});

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    amount DECIMAL(10,2) NOT NULL,
    source TEXT NOT NULL,
    date DATE NOT NULL,
    observation TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT NOT NULL,
    category_id INTEGER,
    date DATE NOT NULL,
    observation TEXT,
    FOREIGN KEY(category_id) REFERENCES categories(id)
  )`);
});

module.exports = db;