const express = require('express');
const path = require('path');
const morgan = require('morgan');
const expressLayouts = require('express-ejs-layouts');

const app = express();
const port = 3000;

// Middleware
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')));
app.use('/js', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')));
app.use('/charts', express.static(path.join(__dirname, 'node_modules/chart.js/dist')));

// View engine setup
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', './views');
app.set('layout', 'layouts/main');

// Routes
app.use('/', require('./routes/dashboard'));
app.use('/categories', require('./routes/categories'));
app.use('/income', require('./routes/income'));
app.use('/expenses', require('./routes/expenses'));

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});